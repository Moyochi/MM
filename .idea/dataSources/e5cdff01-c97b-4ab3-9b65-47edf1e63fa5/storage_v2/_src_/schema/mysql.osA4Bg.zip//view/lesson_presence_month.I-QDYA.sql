create view lesson_presence_month as
  select
    `lesson_count_month`.`student_id`        AS `student_id`,
    `lesson_count_month`.`month`             AS `month`,
    `lesson_count_month`.`subject_id`        AS `subject_id`,
    sum(`lesson_count_month`.`lesson_count`) AS `lesson_count`
  from `mysql`.`lesson_count_month`
  where (`lesson_count_month`.`attend_id` not in (2, 5))
  group by `lesson_count_month`.`student_id`, `lesson_count_month`.`month`, `lesson_count_month`.`subject_id`
  order by `lesson_count_month`.`student_id`, `lesson_count_month`.`month`, `lesson_count_month`.`subject_id`;

