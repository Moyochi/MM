create view lesson_max as
  select
    `mysql`.`lesson_history`.`class_id`          AS `class_id`,
    `mysql`.`lesson_history`.`subject_id`        AS `subject_id`,
    count(`mysql`.`lesson_history`.`subject_id`) AS `lesson_max`
  from `mysql`.`lesson_history`
  group by `mysql`.`lesson_history`.`class_id`, `mysql`.`lesson_history`.`subject_id`
  order by `mysql`.`lesson_history`.`class_id`, `mysql`.`lesson_history`.`subject_id`;

