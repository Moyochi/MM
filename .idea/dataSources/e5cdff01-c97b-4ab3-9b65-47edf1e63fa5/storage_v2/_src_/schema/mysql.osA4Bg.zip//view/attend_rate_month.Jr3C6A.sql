create view attend_rate_month as
  select
    `s`.`student_id`                                                AS `student_id`,
    `rsacm`.`month`                                                 AS `month`,
    ((`rsacm`.`regarding_attend_count` / `amm`.`attend_max`) * 100) AS `attend_rate`
  from ((`mysql`.`regarding_shool_attend_count_month` `rsacm` left join `mysql`.`students` `s`
      on ((`rsacm`.`student_id` = `s`.`student_id`))) left join `mysql`.`attend_max_month` `amm`
      on (((`s`.`class_id` = `amm`.`class_id`) and (`rsacm`.`month` = `amm`.`month`))))
  order by `s`.`student_id`;

