create view attend_max as
  select
    `mysql`.`lesson_history`.`class_id`             AS `class_id`,
    count(distinct `mysql`.`lesson_history`.`date`) AS `attend_max`
  from `mysql`.`lesson_history`
  group by `mysql`.`lesson_history`.`class_id`;

