create view attend_rate as
  select
    `s`.`student_id`                                              AS `student_id`,
    ((`rsac`.`regarding_attend_count` / `am`.`attend_max`) * 100) AS `attend_rate`
  from ((`mysql`.`regarding_shool_attend_count` `rsac` left join `mysql`.`students` `s`
      on ((`rsac`.`student_id` = `s`.`student_id`))) left join `mysql`.`attend_max` `am`
      on ((`s`.`class_id` = `am`.`class_id`)))
  order by `s`.`student_id`;

