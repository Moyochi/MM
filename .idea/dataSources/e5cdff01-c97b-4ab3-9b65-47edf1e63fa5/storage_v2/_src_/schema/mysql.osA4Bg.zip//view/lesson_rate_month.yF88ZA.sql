create view lesson_rate_month as
  select
    `lpm`.`student_id`                                  AS `student_id`,
    `lmm`.`month`                                       AS `month`,
    `lpm`.`subject_id`                                  AS `subject_id`,
    ((`lpm`.`lesson_count` / `lmm`.`lesson_max`) * 100) AS `rate`
  from ((`mysql`.`lesson_presence_month` `lpm` left join `mysql`.`students` `s`
      on ((`lpm`.`student_id` = `s`.`student_id`))) left join `mysql`.`lesson_max_month` `lmm`
      on (((`lpm`.`subject_id` = `lmm`.`subject_id`) and (`s`.`class_id` = `lmm`.`class_id`) and
           (`lpm`.`month` = `lmm`.`month`))))
  order by `s`.`student_id`, `lmm`.`month`, `lmm`.`subject_id`;

