create view regarding_lesson_absence_count_month as
  select
    `lesson_count_month`.`student_id`         AS `student_id`,
    `lesson_count_month`.`month`              AS `month`,
    sum(`lesson_count_month`.`absence_count`) AS `absence_count`
  from `mysql`.`lesson_count_month`
  group by `lesson_count_month`.`student_id`, `lesson_count_month`.`month`;

