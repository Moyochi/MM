create view attend_count as
  select
    `mysql`.`students_attend_school`.`student_id`       AS `student_id`,
    `mysql`.`students_attend_school`.`attend_id`        AS `attend_id`,
    count(`mysql`.`students_attend_school`.`attend_id`) AS `attend_count`
  from `mysql`.`students_attend_school`
  group by `mysql`.`students_attend_school`.`student_id`, `mysql`.`students_attend_school`.`attend_id`;

