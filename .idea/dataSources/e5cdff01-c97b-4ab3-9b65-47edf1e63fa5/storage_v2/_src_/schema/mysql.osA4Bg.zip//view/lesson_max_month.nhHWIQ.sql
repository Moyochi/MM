create view lesson_max_month as
  select
    `mysql`.`lesson_history`.`class_id`                AS `class_id`,
    date_format(`mysql`.`lesson_history`.`date`, '%m') AS `month`,
    `mysql`.`lesson_history`.`subject_id`              AS `subject_id`,
    count(`mysql`.`lesson_history`.`subject_id`)       AS `lesson_max`
  from `mysql`.`lesson_history`
  group by `mysql`.`lesson_history`.`class_id`, date_format(`mysql`.`lesson_history`.`date`, '%m'),
    `mysql`.`lesson_history`.`subject_id`
  order by `mysql`.`lesson_history`.`class_id`, date_format(`mysql`.`lesson_history`.`date`, '%m'),
    `mysql`.`lesson_history`.`subject_id`;

