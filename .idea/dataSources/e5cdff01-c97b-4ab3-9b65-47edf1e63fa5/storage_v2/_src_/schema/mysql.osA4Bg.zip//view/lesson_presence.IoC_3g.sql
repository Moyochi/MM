create view lesson_presence as
  select
    `lesson_count`.`student_id`        AS `student_id`,
    `lesson_count`.`subject_id`        AS `subject_id`,
    sum(`lesson_count`.`lesson_count`) AS `lesson_count`
  from `mysql`.`lesson_count`
  where (`lesson_count`.`attend_id` not in (2, 5))
  group by `lesson_count`.`student_id`, `lesson_count`.`subject_id`
  order by `lesson_count`.`student_id`, `lesson_count`.`subject_id`;

