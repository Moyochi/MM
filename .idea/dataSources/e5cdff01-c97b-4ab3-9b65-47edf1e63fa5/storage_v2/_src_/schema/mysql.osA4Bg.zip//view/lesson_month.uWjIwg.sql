create view lesson_month as
  select distinct date_format(`mysql`.`lesson_history`.`date`, '%m') AS `month`
  from `mysql`.`lesson_history`;

