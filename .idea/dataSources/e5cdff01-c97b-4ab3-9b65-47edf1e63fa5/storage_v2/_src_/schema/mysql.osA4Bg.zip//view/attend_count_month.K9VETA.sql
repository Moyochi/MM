create view attend_count_month as
  select
    `mysql`.`students_attend_school`.`student_id`              AS `student_id`,
    date_format(`mysql`.`students_attend_school`.`date`, '%m') AS `month`,
    `mysql`.`students_attend_school`.`attend_id`               AS `attend_id`,
    count(`mysql`.`students_attend_school`.`attend_id`)        AS `attend_count`
  from `mysql`.`students_attend_school`
  group by `mysql`.`students_attend_school`.`student_id`, `mysql`.`students_attend_school`.`attend_id`,
    date_format(`mysql`.`students_attend_school`.`date`, '%m')
  order by `mysql`.`students_attend_school`.`student_id`, date_format(`mysql`.`students_attend_school`.`date`, '%m'),
    `mysql`.`students_attend_school`.`attend_id`;

