create view attend_max_month as
  select
    `mysql`.`lesson_history`.`class_id`                AS `class_id`,
    date_format(`mysql`.`lesson_history`.`date`, '%m') AS `month`,
    count(distinct `mysql`.`lesson_history`.`date`)    AS `attend_max`
  from `mysql`.`lesson_history`
  group by `mysql`.`lesson_history`.`class_id`, date_format(`mysql`.`lesson_history`.`date`, '%m')
  order by `mysql`.`lesson_history`.`class_id`, date_format(`mysql`.`lesson_history`.`date`, '%m');

