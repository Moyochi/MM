create view lesson_count as
  select
    `mysql`.`students_attend_lesson`.`student_id`                                 AS `student_id`,
    `mysql`.`students_attend_lesson`.`subject_id`                                 AS `subject_id`,
    `mysql`.`students_attend_lesson`.`attend_id`                                  AS `attend_id`,
    count(`mysql`.`students_attend_lesson`.`attend_id`)                           AS `lesson_count`,
    floor((count(`mysql`.`students_attend_lesson`.`attend_id`) * (case `mysql`.`students_attend_lesson`.`attend_id`
                                                                  when '1'
                                                                    then '0'
                                                                  when '2'
                                                                    then '0'
                                                                  when '3'
                                                                    then '0.2'
                                                                  when '4'
                                                                    then '0.2'
                                                                  when '5'
                                                                    then '0.25'
                                                                  else '0' end))) AS `absence_count`
  from `mysql`.`students_attend_lesson`
  group by `mysql`.`students_attend_lesson`.`student_id`, `mysql`.`students_attend_lesson`.`subject_id`,
    `mysql`.`students_attend_lesson`.`attend_id`
  order by `mysql`.`students_attend_lesson`.`student_id`, `mysql`.`students_attend_lesson`.`subject_id`,
    `mysql`.`students_attend_lesson`.`attend_id`;

