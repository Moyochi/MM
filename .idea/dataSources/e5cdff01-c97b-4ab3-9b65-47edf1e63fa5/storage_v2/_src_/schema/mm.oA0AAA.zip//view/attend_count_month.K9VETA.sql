create view attend_count_month as
  select
    `mm`.`students_attend_school`.`student_id`              AS `student_id`,
    date_format(`mm`.`students_attend_school`.`date`, '%m') AS `month`,
    `mm`.`students_attend_school`.`attend_id`               AS `attend_id`,
    count(`mm`.`students_attend_school`.`attend_id`)        AS `attend_count`
  from `mm`.`students_attend_school`
  group by `mm`.`students_attend_school`.`student_id`, `mm`.`students_attend_school`.`attend_id`,
    date_format(`mm`.`students_attend_school`.`date`, '%m')
  order by `mm`.`students_attend_school`.`student_id`, date_format(`mm`.`students_attend_school`.`date`, '%m'),
    `mm`.`students_attend_school`.`attend_id`;

