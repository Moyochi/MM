create view regarding_shool_attend_count as
  select
    `ac`.`student_id`                                                                            AS `student_id`,
    (((sum((`ac`.`attend_count` * (case `ac`.`attend_id`
                                   when '2'
                                     then '0'
                                   else '1' end))) - floor(sum((`ac`.`attend_count` * (case `ac`.`attend_id`
                                                                                       when '3'
                                                                                         then '0.2'
                                                                                       else '0' end))))) -
      floor(sum((`ac`.`attend_count` * (case `ac`.`attend_id`
                                        when '4'
                                          then '0.2'
                                        else '0' end))))) - coalesce(`rlac`.`absence_count`,
                                                                     0))                         AS `regarding_attend_count`
  from (`mm`.`attend_count` `ac` left join `mm`.`regarding_lesson_absence_count` `rlac`
      on ((`ac`.`student_id` = `rlac`.`student_id`)))
  group by `ac`.`student_id`;

