create view lesson_month as
  select distinct date_format(`mm`.`lesson_history`.`date`, '%m') AS `month`
  from `mm`.`lesson_history`;

