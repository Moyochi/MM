create view lesson_rate_month as
  select
    `lpm`.`student_id`                                  AS `student_id`,
    `lmm`.`month`                                       AS `month`,
    `lpm`.`subject_id`                                  AS `subject_id`,
    ((`lpm`.`lesson_count` / `lmm`.`lesson_max`) * 100) AS `rate`
  from ((`mm`.`lesson_presence_month` `LPM` left join `mm`.`students` `S`
      on ((`lpm`.`student_id` = `S`.`student_id`))) left join `mm`.`lesson_max_month` `LMM`
      on (((`lpm`.`subject_id` = `lmm`.`subject_id`) and (`S`.`class_id` = `lmm`.`class_id`) and
           (`lpm`.`month` = `lmm`.`month`))))
  order by `S`.`student_id`, `lmm`.`month`, `lmm`.`subject_id`;

