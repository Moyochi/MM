create view lesson_rate as
  select
    `lp`.`student_id`                                 AS `student_id`,
    `lp`.`subject_id`                                 AS `subject_id`,
    ((`lp`.`lesson_count` / `lm`.`lesson_max`) * 100) AS `rate`
  from
    ((`mm`.`lesson_presence` `LP` left join `mm`.`students` `S` on ((`lp`.`student_id` = `S`.`student_id`))) left join
      `mm`.`lesson_max` `LM` on (((`lp`.`subject_id` = `lm`.`subject_id`) and (`S`.`class_id` = `lm`.`class_id`))))
  order by `S`.`student_id`, `lm`.`subject_id`;

