create view attend_max as
  select
    `mm`.`lesson_history`.`class_id`             AS `class_id`,
    count(distinct `mm`.`lesson_history`.`date`) AS `attend_max`
  from `mm`.`lesson_history`
  group by `mm`.`lesson_history`.`class_id`;

