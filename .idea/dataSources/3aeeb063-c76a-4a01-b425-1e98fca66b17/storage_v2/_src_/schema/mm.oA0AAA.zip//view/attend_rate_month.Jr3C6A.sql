create view attend_rate_month as
  select
    `S`.`student_id`                                                AS `student_id`,
    `RSACM`.`month`                                                 AS `month`,
    ((`RSACM`.`regarding_attend_count` / `amm`.`attend_max`) * 100) AS `attend_rate`
  from ((`mm`.`regarding_shool_attend_count_month` `RSACM` left join `mm`.`students` `S`
      on ((`RSACM`.`student_id` = `S`.`student_id`))) left join `mm`.`attend_max_month` `AMM`
      on (((`S`.`class_id` = `amm`.`class_id`) and (`RSACM`.`month` = `amm`.`month`))))
  order by `S`.`student_id`;

