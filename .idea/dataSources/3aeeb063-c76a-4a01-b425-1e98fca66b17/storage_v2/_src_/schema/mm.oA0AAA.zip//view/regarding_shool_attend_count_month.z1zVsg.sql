create view regarding_shool_attend_count_month as
  select
    `acm`.`student_id`                                                                             AS `student_id`,
    `acm`.`month`                                                                                  AS `month`,
    (((sum((`acm`.`attend_count` * (case `acm`.`attend_id`
                                    when '2'
                                      then '0'
                                    else '1' end))) - floor(sum((`acm`.`attend_count` * (case `acm`.`attend_id`
                                                                                         when '3'
                                                                                           then '0.2'
                                                                                         else '0' end))))) -
      floor(sum((`acm`.`attend_count` * (case `acm`.`attend_id`
                                         when '4'
                                           then '0.2'
                                         else '0' end))))) - coalesce(`rlacm`.`absence_count`,
                                                                      0))                          AS `regarding_attend_count`
  from (`mm`.`attend_count_month` `ACM` left join `mm`.`regarding_lesson_absence_count_month` `RLACM`
      on (((`acm`.`student_id` = `rlacm`.`student_id`) and (`acm`.`month` = `rlacm`.`month`))))
  group by `acm`.`student_id`, `acm`.`month`;

