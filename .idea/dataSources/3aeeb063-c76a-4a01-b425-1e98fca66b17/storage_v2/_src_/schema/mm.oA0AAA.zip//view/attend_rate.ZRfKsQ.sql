create view attend_rate as
  select
    `S`.`student_id`                                              AS `student_id`,
    ((`RSAC`.`regarding_attend_count` / `am`.`attend_max`) * 100) AS `attend_rate`
  from ((`mm`.`regarding_shool_attend_count` `RSAC` left join `mm`.`students` `S`
      on ((`RSAC`.`student_id` = `S`.`student_id`))) left join `mm`.`attend_max` `AM`
      on ((`S`.`class_id` = `am`.`class_id`)))
  order by `S`.`student_id`;

