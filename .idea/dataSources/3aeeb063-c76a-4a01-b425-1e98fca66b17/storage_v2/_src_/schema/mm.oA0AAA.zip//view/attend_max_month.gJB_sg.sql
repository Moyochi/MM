create view attend_max_month as
  select
    `mm`.`lesson_history`.`class_id`                AS `class_id`,
    date_format(`mm`.`lesson_history`.`date`, '%m') AS `month`,
    count(distinct `mm`.`lesson_history`.`date`)    AS `attend_max`
  from `mm`.`lesson_history`
  group by `mm`.`lesson_history`.`class_id`, date_format(`mm`.`lesson_history`.`date`, '%m')
  order by `mm`.`lesson_history`.`class_id`, date_format(`mm`.`lesson_history`.`date`, '%m');

