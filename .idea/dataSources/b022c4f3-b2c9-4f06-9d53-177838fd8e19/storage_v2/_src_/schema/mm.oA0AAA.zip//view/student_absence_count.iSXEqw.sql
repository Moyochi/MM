create view student_absence_count as
  select
    `mm`.`students_attend_lesson`.`student_id` AS `student_id`,
    `mm`.`students_attend_lesson`.`date`       AS `date`,
    count(0)                                   AS `count`
  from `mm`.`students_attend_lesson`
  where (`mm`.`students_attend_lesson`.`attend_id` = 2)
  group by `mm`.`students_attend_lesson`.`student_id`, `mm`.`students_attend_lesson`.`date`;

