create view attend_rate as
  select
    `S`.`student_id`                                     AS `student_id`,
    `S`.`class_id`                                       AS `class_id`,
    `S`.`student_name`                                   AS `student_name`,
    `acp`.`presence_count`                               AS `presence_count`,
    ((`acp`.`presence_count` / `am`.`attend_max`) * 100) AS `attend_rate`,
    coalesce(`aca`.`absence_count`, 0)                   AS `absence_count`
  from ((((`mm`.`students` `S` left join `mm`.`regarding_shool_attend_count` `RSAC`
      on ((`S`.`student_id` = `rsac`.`student_id`))) left join `mm`.`attend_max` `AM`
      on ((`am`.`class_id` = `S`.`class_id`))) left join `mm`.`attend_count_presence` `ACP`
      on ((`S`.`student_id` = `acp`.`student_id`))) left join `mm`.`attend_count_absence` `ACA`
      on ((`S`.`student_id` = `aca`.`student_id`)));

