create view attend_count as
  select
    `mm`.`students_attend_shool`.`student_id`       AS `student_id`,
    `mm`.`students_attend_shool`.`attend_id`        AS `attend_id`,
    count(`mm`.`students_attend_shool`.`attend_id`) AS `attend_count`
  from `mm`.`students_attend_shool`
  group by `mm`.`students_attend_shool`.`student_id`, `mm`.`students_attend_shool`.`attend_id`
  order by `mm`.`students_attend_shool`.`student_id`;

