create view regarding_lesson_absence_count as
  select
    `lesson_count`.`student_id`         AS `student_id`,
    sum(`lesson_count`.`absence_count`) AS `absence_count`
  from `mm`.`lesson_count`
  group by `lesson_count`.`student_id`;

