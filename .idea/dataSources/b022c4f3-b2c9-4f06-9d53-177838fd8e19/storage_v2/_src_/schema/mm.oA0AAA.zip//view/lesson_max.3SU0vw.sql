create view lesson_max as
  select
    `mm`.`lesson_history`.`class_id`          AS `class_id`,
    `mm`.`lesson_history`.`subject_id`        AS `subject_id`,
    count(`mm`.`lesson_history`.`subject_id`) AS `lesson_max`
  from `mm`.`lesson_history`
  where (`mm`.`lesson_history`.`date` between '2019-10-01 00:00:00' and '2019-10-31 23:59:59')
  group by `mm`.`lesson_history`.`subject_id`
  order by `mm`.`lesson_history`.`subject_id`;

