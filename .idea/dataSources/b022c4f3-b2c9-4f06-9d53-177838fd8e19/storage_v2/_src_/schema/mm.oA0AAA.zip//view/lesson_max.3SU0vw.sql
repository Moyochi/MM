create view lesson_max as
  select
    `mm`.`lesson_history`.`class_id`          AS `class_id`,
    `mm`.`lesson_history`.`subject_id`        AS `subject_id`,
    count(`mm`.`lesson_history`.`subject_id`) AS `lesson_max`
  from `mm`.`lesson_history`
  group by `mm`.`lesson_history`.`class_id`, `mm`.`lesson_history`.`subject_id`
  order by `mm`.`lesson_history`.`class_id`, `mm`.`lesson_history`.`subject_id`;

