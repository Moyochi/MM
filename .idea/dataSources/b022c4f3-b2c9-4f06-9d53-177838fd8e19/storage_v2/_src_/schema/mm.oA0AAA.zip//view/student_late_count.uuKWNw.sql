create view student_late_count as
  select
    `sac`.`student_id` AS `student_id`,
    sum(`sac`.`count`) AS `count`
  from (`mm`.`student_attend_date` `SAD`
    join `mm`.`student_absence_count` `SAC`
      on (((`sad`.`student_id` = `sac`.`student_id`) and (`sad`.`date` = `sac`.`date`))))
  group by `sac`.`student_id`;

