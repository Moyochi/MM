create view regarding_lesson_attend_count as
  select
    `lesson_count`.`student_id`                      AS `student_id`,
    `lesson_count`.`subject_id`                      AS `subject_id`,
    (`lesson_count`.`lesson_count` * (case `lesson_count`.`attend_id`
                                      when '1'
                                        then '1'
                                      else '0' end)) AS `attend_count`,
    (`lesson_count`.`lesson_count` * (case `lesson_count`.`attend_id`
                                      when '1'
                                        then '0'
                                      else '1' end)) AS `absence_count`
  from `mm`.`lesson_count`
  group by `lesson_count`.`student_id`, `lesson_count`.`subject_id`
  order by `lesson_count`.`student_id`;

