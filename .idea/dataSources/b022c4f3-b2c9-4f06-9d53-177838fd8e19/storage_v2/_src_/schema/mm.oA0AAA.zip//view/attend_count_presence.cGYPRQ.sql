create view attend_count_presence as
  select
    `S`.`student_id`                 AS `student_id`,
    coalesce(`ac`.`attend_count`, 0) AS `presence_count`
  from (`mm`.`students` `S` left join `mm`.`attend_count` `AC` on ((`S`.`student_id` = `ac`.`student_id`)))
  where ((`ac`.`attend_id` = 1) or isnull(`ac`.`attend_count`));

