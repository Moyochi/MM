create view lesson_count as
  select
    `mm`.`students_attend_lesson`.`student_id`                                 AS `student_id`,
    `mm`.`students_attend_lesson`.`subject_id`                                 AS `subject_id`,
    `mm`.`students_attend_lesson`.`attend_id`                                  AS `attend_id`,
    count(`mm`.`students_attend_lesson`.`attend_id`)                           AS `lesson_count`,
    floor((count(`mm`.`students_attend_lesson`.`attend_id`) * (case `mm`.`students_attend_lesson`.`attend_id`
                                                               when '1'
                                                                 then '0'
                                                               when '2'
                                                                 then '0'
                                                               when '3'
                                                                 then '0.2'
                                                               when '4'
                                                                 then '0.2'
                                                               when '5'
                                                                 then '0.25'
                                                               else '0' end))) AS `absence_count`
  from `mm`.`students_attend_lesson`
  group by `mm`.`students_attend_lesson`.`student_id`, `mm`.`students_attend_lesson`.`subject_id`,
    `mm`.`students_attend_lesson`.`attend_id`
  order by `mm`.`students_attend_lesson`.`student_id`, `mm`.`students_attend_lesson`.`subject_id`,
    `mm`.`students_attend_lesson`.`attend_id`;

