create view lesson_count as
  select
    `mm`.`students_attend_lesson`.`student_id`       AS `student_id`,
    `mm`.`students_attend_lesson`.`subject_id`       AS `subject_id`,
    `mm`.`students_attend_lesson`.`attend_id`        AS `attend_id`,
    count(`mm`.`students_attend_lesson`.`attend_id`) AS `lesson_count`
  from `mm`.`students_attend_lesson`
  where (`mm`.`students_attend_lesson`.`date` between '2019-10-01 00:00:00' and '2019-10-31 23:59:59')
  group by `mm`.`students_attend_lesson`.`student_id`, `mm`.`students_attend_lesson`.`subject_id`,
    `mm`.`students_attend_lesson`.`attend_id`
  order by `mm`.`students_attend_lesson`.`student_id`, `mm`.`students_attend_lesson`.`subject_id`;

