create view student_attend_date as
  select
    `mm`.`students_attend_shool`.`student_id` AS `student_id`,
    `mm`.`students_attend_shool`.`date`       AS `date`
  from `mm`.`students_attend_shool`
  where (`mm`.`students_attend_shool`.`attend_id` = 1);

