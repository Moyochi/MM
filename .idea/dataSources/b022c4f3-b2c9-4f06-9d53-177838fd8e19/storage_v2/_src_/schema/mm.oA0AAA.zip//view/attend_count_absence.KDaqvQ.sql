create view attend_count_absence as
  select
    `S`.`student_id`    AS `student_id`,
    `ac`.`attend_count` AS `absence_count`
  from (`mm`.`students` `S` left join `mm`.`attend_count` `AC` on ((`S`.`student_id` = `ac`.`student_id`)))
  where (`ac`.`attend_id` = 2);

