create view regarding_shool_attend_count as
  select
    `aca`.`student_id`                                   AS `student_id`,
    (`aca`.`absence_count` + coalesce(`slc`.`count`, 0)) AS `absence`
  from (`mm`.`attend_count_absence` `ACA` left join `mm`.`student_late_count` `SLC`
      on ((`aca`.`student_id` = `slc`.`student_id`)));

