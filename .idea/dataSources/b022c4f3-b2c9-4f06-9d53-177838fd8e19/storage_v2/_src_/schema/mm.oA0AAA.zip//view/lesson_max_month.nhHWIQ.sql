create view lesson_max_month as
  select
    `mm`.`lesson_history`.`class_id`                AS `class_id`,
    date_format(`mm`.`lesson_history`.`date`, '%m') AS `month`,
    `mm`.`lesson_history`.`subject_id`              AS `subject_id`,
    count(`mm`.`lesson_history`.`subject_id`)       AS `lesson_max`
  from `mm`.`lesson_history`
  group by `mm`.`lesson_history`.`class_id`, date_format(`mm`.`lesson_history`.`date`, '%m'),
    `mm`.`lesson_history`.`subject_id`
  order by `mm`.`lesson_history`.`class_id`, date_format(`mm`.`lesson_history`.`date`, '%m'),
    `mm`.`lesson_history`.`subject_id`;

