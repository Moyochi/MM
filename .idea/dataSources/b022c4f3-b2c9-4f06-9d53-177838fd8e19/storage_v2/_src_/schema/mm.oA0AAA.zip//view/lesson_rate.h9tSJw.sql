create view lesson_rate as
  select
    `lp`.`student_id`                                 AS `student_id`,
    `lp`.`subject_id`                                 AS `subject_id`,
    ((`lp`.`lesson_count` / `lm`.`lesson_max`) * 100) AS `rate`
  from
    ((`mm`.`lesson_presence` `lp` left join `mm`.`students` `s` on ((`lp`.`student_id` = `s`.`student_id`))) left join
      `mm`.`lesson_max` `lm` on (((`lp`.`subject_id` = `lm`.`subject_id`) and (`s`.`class_id` = `lm`.`class_id`))))
  order by `s`.`student_id`, `lm`.`subject_id`;

