create view lesson_rate as
  select
    `ra`.`student_id`                                                                                         AS `student_id`,
    `ra`.`subject_id`                                                                                         AS `subject_id`,
    coalesce(((ceiling((`ra`.`attend_count` + (`ra`.`absence_count` * 0.75))) / `lm`.`lesson_max`) * 100), 0) AS `rate`
  from (`mm`.`regarding_lesson_attend_count` `RA` left join `mm`.`lesson_max` `LM`
      on ((`ra`.`subject_id` = `lm`.`subject_id`)));

